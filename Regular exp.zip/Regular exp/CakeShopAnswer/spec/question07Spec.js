describe('Question Seven', function () {
  describe('MumsPalace.getCakeShopsWithTwoCakes function', function () {
    var theMumsPalace
    beforeEach(
            function () {
              theMumsPalace = Controller.setup()
            }
        )

    it('should be defined', function () {
      expect(theMumsPalace.getCakeShops()).toBeDefined()
    })
    it('should return a string', function () {
      expect(typeof theMumsPalace.getCakeShopsWithTwoCakes()).toBe('string')
    })

    it('should NOT be hard coded', function () {
      theMumsPalace = new MumsPalace()
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toBe('')
    })

	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/The\sBagel\sShop/)
	});
	

	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Chocolate[.]/)
	});
	
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+Angel[\s]cake/)
	});
	
	it('should correctly report origin of cake ', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+[\S]United\sKingdom[\S]/)
	});
	
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]\d[\S]+/)
	});
	
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sBabka/)
	});
	
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\s]+[\S]Poland[\S]/)
	});
	
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$][\d]+[\S]+/)
	});
	
	
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Patty[\s]Cakes/)
	});
 
 
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Butterscotch[.]/)
	 	}); 
		

	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sCheesecake\s+/)
	  
	});
	
	  it('should correctly report origin of cake ', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SGreece\S\s+/)
	});
	
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$][\d]+[\S]+/)
	});
	
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sPanettone\s+/)
	});
	
	it('should correctly report origin of cake', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SItaly\S\s+/)
	});
	
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$]\d+[\S]+/)
	});
	/*
    it('should correctly report details of CakeShops who has 2 Cakes in order', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toBe('The Bagel Shop, Chocolate. <01>\n	Angel cake  (United Kingdom) worth $20\n	Babka  (Poland) worth $15\nPatty Cakes, Butterscotch. <04>\n	Cheesecake  (Greece) worth $20\n	Panettone  (Italy) worth $15\n')
    })*/
	
  })
})