describe('Question Three', function () {
  describe('MumsPalace.getCakeShop function', function () {
    var theMumsPalace
    beforeEach(function () {
      theMumsPalace = Controller.setup()
    })

    it('should exist', function () {
      expect(theMumsPalace.getCakeShops).toBeDefined()
    })
    it('should return a string', function () {
      expect(typeof theMumsPalace.getCakeShops()).toBe('string')
    })

    it('should NOT be hard coded', function () {
      theMumsPalace = new MumsPalace()
      expect(theMumsPalace.getCakeShops()).toBe('')
    })

	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/The\sBagel\sShop/)
	});
	
	
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/\sChocolate[.]/)
	});
	
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/Hot\sCrossed\sBuns,/)
	});
	
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/\sVanilla./)
	});
	  
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/Sugar\sBooger/)
	});
	
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/\sRed\sVelvet[.]/)
	});
	
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/Patty\sCakes[,]/)
	});
	
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/\sButterscotch[.]/)
	});
	
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	/*
    it('should return correctly formatted data in the right order', function () {
      expect(theMumsPalace.getCakeShops()).toBe('The Bagel Shop, Chocolate. <01>\nHot Crossed Buns, Vanilla. <02>\nSugar Booger, Red Velvet. <03>\nPatty Cakes, Butterscotch. <04>\n')
    })
	*/
  });
});