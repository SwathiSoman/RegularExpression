describe('Question Seven', function () {
  describe('MumsPalace.getCakeShopsWithTwoCakes function', function () {
    var theMumsPalace
    beforeEach(
            function () {
              theMumsPalace = Controller.setup()
            }
        )

				it('should be defined', function () {
				  expect(theMumsPalace.getCakeShops()).toBeDefined()
				})
				it('should return a string', function () {
				  expect(typeof theMumsPalace.getCakeShopsWithTwoCakes()).toBe('string')
				})

				it('should NOT be hard coded', function () {
				  theMumsPalace = new MumsPalace()
				  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toBe('')
				})
    
					describe( 'Check First Name', function () {
							it('should correctly report the firstName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/The\sBagel\sShop/)
							});
					})
					describe( 'Check for Flavour', function () {
							it('should correctly report the flavour', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Chocolate[.]/)
							});
					})
					describe( 'Check for Cake Id', function () {
							it('should correctly report the id', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
							});
					})
					describe( 'Check for Cake Name', function () {
							it('should correctly report the cakeName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+Angel[\s]cake/)
							});
					})
					describe( 'Check for Origin of Cake', function () {
							it('should correctly report origin of cake ', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+[\S]United\sKingdom[\S]/)
							});
					})
					describe( 'Check for Cost of Cake', function () {
							it('should correctly report worth $', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]\d[\S]+/)
							});
					})
					describe( 'Check for Cake Name', function () {
							it('should correctly report the cakeName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sBabka/)
							});
					})
					describe( 'Check for Origin of Cake', function () {
							it('should correctly report origin of cake', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\s]+[\S]Poland[\S]/)
							});
					})
					describe( 'Check for Cost of Cake', function () {
							it('should correctly report worth $', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$][\d]+[\S]+/)
							});
					})
					describe( 'Check for First Name', function () {
							it('should correctly report the firstName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Patty[\s]Cakes/)
							});
					})
					describe( 'Check for Flavour', function () {
							it('should correctly report the flavour', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Butterscotch[.]/)
								}); 
					})	
					describe( 'Check for Cake Id', function () {
							it('should correctly report the id', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
							});
					})
					describe( 'Check for Cake Name', function () {
							it('should correctly report the cakeName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sCheesecake\s+/)
							  
							});
					})
					describe( 'Check for Origin of Cake', function () {
							 it('should correctly report origin of cake ', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SGreece\S\s+/)
							});
					})
					describe( 'Check for Cost of Cake', function () {
							it('should correctly report worth $', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$][\d]+[\S]+/)
							});
					})
					describe( 'Check for Cake Name', function () {
							it('should correctly report the cakeName', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sPanettone\s+/)
							});
					})
					describe( 'Check for Origin of Cake', function () {
							it('should correctly report origin of cake', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SItaly\S\s+/)
							});
					})
					describe( 'Check for Cost of Cake', function () {
							it('should correctly report worth $', function () {
							  expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$]\d+[\S]+/)
							});
					})		
				
	            //The Bagel Shop, Chocolate. <01>\n    Angel cake (United Kingdom) worth $20.\n    Babka (Poland) worth $15.\nPatty Cakes, Butterscotch. <04>\n    Cheesecake (Greece) worth $20.\n    Panettone (Italy) worth $15.\n//
	
		})
	})