class Cake {
	constructor (theCakeShop, newId, newCakeName, newOrigin, newCost) {
		// ADD CODE HERE
	
	}
	
}