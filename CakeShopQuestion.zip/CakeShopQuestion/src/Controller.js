class Controller {

	static setup  () {
		var theMumsPalace
		theMumsPalace = new MumsPalace();
		// ADD CODE HERE TO CREATE THE CAKESHOPS
		/*
		ID       FIRST NAME              Flavour          Place

        01      The Bagel Shop      	Chocolate         Moorhouse
        02      Hot Crossed Buns    	Vanilla           Linwood
        03      Sugar Booger     	    Red Velvet        Shirley
        04      Patty Cakes   	        Butterscotch      Hornby

		*/
		
        
		// ADD CODE HERE TO CREATE THE CAKESHOPS
		/*
			Shop  ID   CAKENAME             Origin          Cost
			01  401   Angel cake             United Kingdom      $20
			01  402   Babka                  Poland              $15
			03  389   Boston cream pie       United States       $25
			02  113   Black Forest cake      Germany             $30
			04  114   Cheesecake             Greece              $20
			04  121   Panettone              Italy		       $15

		*/
		
	}
}