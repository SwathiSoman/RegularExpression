describe('Question Seven', function () {
  describe('MumsPalace.getCakeShopsWithTwoCakes function', function () {
    var theMumsPalace
    beforeEach(
            function () {
              theMumsPalace = Controller.setup()
            }
        )

    it('should be defined', function () {
      expect(theMumsPalace.getCakeShops()).toBeDefined()
    })
    it('should return a string', function () {
      expect(typeof theMumsPalace.getCakeShopsWithTwoCakes()).toBe('string')
    })

    it('should NOT be hard coded', function () {
      theMumsPalace = new MumsPalace()
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toBe('')
    })
    
	describe( 'First Name', function () {
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/The\sBagel\sShop/)
	});
	
	describe( 'Flavour', function () {
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Chocolate[.]/)
	});
	
	describe( 'Cake Id', function () {
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	describe( 'Cake Name', function () {
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+Angel[\s]cake/)
	});
	
	describe( 'Origin of Cake', function () {
	it('should correctly report origin of cake ', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\s+[\S]United\sKingdom[\S]/)
	});
	
	describe( 'Cost of Cake', function () {
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$]\d[\S]+/)
	});
	
	describe( 'Cake Name', function () {
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sBabka/)
	});
	
	describe( 'Origin of Cake', function () {
	it('should correctly report origin of cake', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[\s]+[\S]Poland[\S]/)
	});
	
	describe( 'Cost of Cake', function () {
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sworth\s[$][\d]+[\S]+/)
	});
	
	describe( 'First Name', function () {
	it('should correctly report the firstName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/Patty[\s]Cakes/)
	});
 
    describe( 'Flavour', function () {
	it('should correctly report the flavour', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[,][\s]Butterscotch[.]/)
	 	}); 
		
    describe( 'Cake Id', function () {
	it('should correctly report the id', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/[A-Z][a-z][\s\S]+/)
	});
	
	describe( 'Cake Name', function () {
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sCheesecake\s+/)
	  
	});
	
	describe( 'Origin of Cake', function () {
	  it('should correctly report origin of cake ', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SGreece\S\s+/)
	});
	
	describe( 'Cost of Cake', function () {
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$][\d]+[\S]+/)
	});
	
	describe( 'Cake Name', function () {
	it('should correctly report the cakeName', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\sPanettone\s+/)
	});
	
	describe( 'Origin of Cake', function () {
	it('should correctly report origin of cake', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/\SItaly\S\s+/)
	});
	
	describe( 'Cost of Cake', function () {
	it('should correctly report worth $', function () {
      expect(theMumsPalace.getCakeShopsWithTwoCakes()).toMatch(/worth\s[$]\d+[\S]+/)
	});
	})
	
	})
	})
	})
	})
	})
	})
	})
	})
	})
	})
	})
	})
	})
    })
	})
	})
	})	
  })
})