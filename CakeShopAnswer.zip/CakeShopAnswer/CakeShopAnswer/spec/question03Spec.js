describe('Question Three', function () {
				  describe('MumsPalace.getCakeShop function', function () {
					var theMumsPalace
					beforeEach(function () {
					  theMumsPalace = Controller.setup()
					})

						it('should exist', function () {
						  expect(theMumsPalace.getCakeShops).toBeDefined()
						})
						it('should return a string', function () {
						  expect(typeof theMumsPalace.getCakeShops()).toBe('string')
						})

						it('should NOT be hard coded', function () {
						  theMumsPalace = new MumsPalace()
						  expect(theMumsPalace.getCakeShops()).toBe('')
						})

							describe('Check First Name', function () {
										it('should correctly report the firstName', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/The\sBagel\sShop/)
										});
									})
					
							describe('Check for Cake Flavour', function () {
										it('should correctly report the flavour', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/\sChocolate[.]/)
										});
									})
								
							describe('Check for Cake Id', function () {
										it('should correctly report the id', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
										});
									})
							describe('Check First Name', function () {
										it('should correctly report the firstName', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/Hot\sCrossed\sBuns,/)
										});
									})
							describe('Check for Cake Flavour', function () {
										it('should correctly report the flavour', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/\sVanilla./)
										});
									})
							describe('Check for Cake Id', function () {
										it('should correctly report the id', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
										});
									})
					
							describe('Check First Name', function () {
										it('should correctly report the firstName', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/Sugar\sBooger/)
										});
									})
							describe('Check for Cake Flavour', function () {
										it('should correctly report the flavour', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/\sRed\sVelvet[.]/)
										});
									})
							describe('Check for Cake Id', function () {
										it('should correctly report the id', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
										});
									})
							describe('Check First Name', function () {
										it('should correctly report the firstName', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/Patty\sCakes[,]/)
										});
									})
							describe('Check for Cake Flavour', function () {
										it('should correctly report the flavour', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/\sButterscotch[.]/)
										});
									})
							describe('Check for Cake Id', function () {
										it('should correctly report the id', function () {
										  expect(theMumsPalace.getCakeShops()).toMatch(/[A-Z][a-z][\s\S]+/)
										});
									})
					
	                        //The Bagel Shop, Chocolate. <01>\nHot Crossed Buns, Vanilla. <02>\nSugar Booger, Red Velvet. <03>\nPatty Cakes, Butterscotch. <04>\n//
				});
			});